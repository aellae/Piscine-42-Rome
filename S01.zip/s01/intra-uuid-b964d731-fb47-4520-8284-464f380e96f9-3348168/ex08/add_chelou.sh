#!/bin/sh
echo $FT_NBR1 + $FT_NBR2 | sed s/\'/0/g | tr '\\\"?!' '1234' | tr 'mrdoc' '012345' | xargs echo "obase=13; ibase=5;" | bc | tr '012345678ABC' 'gtaio luSnemf'
